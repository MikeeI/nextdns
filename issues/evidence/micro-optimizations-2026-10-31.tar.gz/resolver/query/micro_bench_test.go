package query

import (
	"fmt"
	"hash/fnv"
	"net"
	"testing"

	"golang.org/x/net/dns/dnsmessage"
)

var microQuerySink Query

func microPayload(b testing.TB, options []dnsmessage.Option, opt bool) []byte {
	b.Helper()
	name, err := dnsmessage.NewName("printer.local.")
	if err != nil {
		b.Fatal(err)
	}
	msg := dnsmessage.Message{Header: dnsmessage.Header{ID: 123, RecursionDesired: true}, Questions: []dnsmessage.Question{{Name: name, Type: dnsmessage.TypeA, Class: dnsmessage.ClassINET}}}
	if opt {
		msg.Additionals = []dnsmessage.Resource{{Header: dnsmessage.ResourceHeader{Name: dnsmessage.MustNewName("."), Type: dnsmessage.TypeOPT, Class: 1232}, Body: &dnsmessage.OPTResource{Options: options}}}
	}
	payload, err := msg.Pack()
	if err != nil {
		b.Fatal(err)
	}
	return payload
}

func BenchmarkMicroQuery(b *testing.B) {
	cases := []struct {
		name    string
		opt     bool
		options []dnsmessage.Option
	}{
		{"plain", false, nil}, {"empty-opt", true, nil},
		{"unknown-opt", true, []dnsmessage.Option{{Code: 65000, Data: []byte{1, 2, 3, 4}}}},
		{"ecs4", true, []dnsmessage.Option{{Code: EDNS0_SUBNET, Data: []byte{0, 1, 32, 0, 192, 0, 2, 1}}}},
		{"ecs6", true, []dnsmessage.Option{{Code: EDNS0_SUBNET, Data: []byte{0, 2, 128, 0, 32, 1, 13, 184, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}}}},
	}
	for _, tc := range cases {
		b.Run(tc.name, func(b *testing.B) {
			original := microPayload(b, tc.options, tc.opt)
			payload := make([]byte, len(original))
			ip := net.IPv4(127, 0, 0, 1)
			b.ReportAllocs()
			for b.Loop() {
				copy(payload, original)
				q, err := New(payload, ip, ip)
				if err != nil {
					b.Fatal(err)
				}
				microQuerySink = q
			}
		})
	}
}

func TestMicroQueryFingerprint(t *testing.T) {
	h := fnv.New64a()
	for _, opt := range []bool{false, true} {
		for _, opts := range [][]dnsmessage.Option{nil, {{Code: 65000, Data: []byte{1, 2, 3}}}, {{Code: EDNS0_SUBNET, Data: []byte{0, 1, 24, 0, 192, 0, 2, 1}}}, {{Code: 65000, Data: []byte{5}}, {Code: EDNS0_SUBNET, Data: []byte{0, 1, 32, 0, 192, 0, 2, 1}}, {Code: EDNS0_SUBNET, Data: []byte{0, 1, 32, 0, 198, 51, 100, 2}}}} {
			payload := microPayload(t, opts, opt)
			for size := range len(payload) + 1 {
				input := append([]byte(nil), payload[:size]...)
				q, err := New(input, net.IPv4(127, 0, 0, 1), nil)
				fmt.Fprintf(h, "%#v/%v/%x\n", q, err, input)
			}
		}
	}
	t.Logf("query-fingerprint=%x", h.Sum64())
}
