package resolver

import (
	"testing"

	"github.com/nextdns/nextdns/resolver/query"
	"golang.org/x/net/dns/dnsmessage"
)

var microHashSink uint64
var microValidSink bool

func BenchmarkMicroHash(b *testing.B) {
	for _, ctx := range []string{"", "https://dns.nextdns.io/abcdef"} {
		b.Run(ctx, func(b *testing.B) {
			k := cacheKey{ctx: ctx, qclass: query.ClassINET, qtype: query.TypeA, qname: "printer.local."}
			b.ReportAllocs()
			for b.Loop() {
				microHashSink = k.Hash()
			}
		})
	}
}

func BenchmarkMicroValidate(b *testing.B) {
	msg, err := (&dnsmessage.Message{Questions: []dnsmessage.Question{{Name: dnsmessage.MustNewName("printer.local."), Type: dnsmessage.TypeA, Class: dnsmessage.ClassINET}}}).Pack()
	if err != nil {
		b.Fatal(err)
	}
	k := cacheKey{qclass: query.ClassINET, qtype: query.TypeA, qname: "printer.local."}
	b.ReportAllocs()
	for b.Loop() {
		microValidSink = k.ValidateQuestion(msg)
	}
}
