package discovery

import (
	"fmt"
	"hash/fnv"
	"strings"
	"testing"
	"time"
)

var microStringSink string
var microStringsSink []string

func BenchmarkMicroPrepare(b *testing.B) {
	for _, name := range []string{"printer.local.", "Printer.Local.", "printer.local", strings.Repeat("a", 63) + ".local."} {
		b.Run(name, func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				microStringSink = prepareHostLookup(name)
			}
		})
	}
}

func BenchmarkMicroLookup(b *testing.B) {
	h := &Hosts{names: map[string][]string{"printer.local.": {"192.0.2.1"}}, expires: time.Now().Add(24 * time.Hour)}
	r := Resolver{h}
	for _, name := range []string{"printer.local.", "Printer.Local.", "missing.local."} {
		b.Run(name, func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				microStringsSink = r.LookupHost(name)
			}
		})
	}
}

func TestMicroNormalizationFingerprint(t *testing.T) {
	h := fnv.New64a()
	inputs := []string{"", ".", "..", "Printer.Local.", "printer.local", "ÄÖÜ.local.", "a..", string([]byte{255, 65, 0, 90, 46})}
	for value := range 256 {
		inputs = append(inputs, string([]byte{byte(value), 'A', '.', byte(value), '.'}))
	}
	for _, input := range inputs {
		fmt.Fprintf(h, "%q=%q\n", input, prepareHostLookup(input))
	}
	t.Logf("normalization-fingerprint=%x", h.Sum64())
}
