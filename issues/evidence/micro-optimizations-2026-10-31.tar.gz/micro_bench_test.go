package main

import (
	"fmt"
	"hash/fnv"
	"net"
	"strings"
	"testing"

	"github.com/nextdns/nextdns/config"
	"github.com/nextdns/nextdns/discovery"
	"github.com/nextdns/nextdns/resolver"
	"github.com/nextdns/nextdns/resolver/query"
)

var microID string
var microClient resolver.ClientInfo

func BenchmarkMicroShortID(b *testing.B) {
	for _, size := range []int{6, 20, 58, 59, 128} {
		b.Run(fmt.Sprint(size), func(b *testing.B) {
			id := []byte(strings.Repeat("x", size))
			b.ReportAllocs()
			for b.Loop() {
				microID = shortID("abcdef", id)
			}
		})
	}
}

func BenchmarkMicroClientInfo(b *testing.B) {
	p := &proxySvc{resolver: &resolver.DNS{}}
	var conf config.Profiles
	if err := conf.Set("abcdef"); err != nil {
		b.Fatal(err)
	}
	setupClientReporting(p, &conf, discovery.Resolver{})
	for _, addr := range []string{"192.0.2.1", "2001:db8::1234"} {
		b.Run(addr, func(b *testing.B) {
			q := query.Query{PeerIP: net.ParseIP(addr)}
			b.ReportAllocs()
			for b.Loop() {
				microClient = p.resolver.DOH.ClientInfo(q)
			}
		})
	}
}

func TestMicroIDFingerprint(t *testing.T) {
	h := fnv.New64a()
	for _, conf := range []string{"", "abcdef", strings.Repeat("p", 64), "a\x00b"} {
		for size := range 140 {
			fmt.Fprintf(h, "%q/%d=%s\n", conf, size, shortID(conf, []byte(strings.Repeat("x", size))))
		}
	}
	p := &proxySvc{resolver: &resolver.DNS{}}
	var conf config.Profiles
	setupClientReporting(p, &conf, discovery.Resolver{})
	for _, ip := range []net.IP{nil, {}, {1, 2, 3}, net.ParseIP("192.0.2.1"), net.ParseIP("::ffff:192.0.2.1"), net.ParseIP("2001:db8::1")} {
		fmt.Fprintf(h, "%#v\n", p.resolver.DOH.ClientInfo(query.Query{PeerIP: ip}))
	}
	t.Logf("id-client-fingerprint=%x", h.Sum64())
}
