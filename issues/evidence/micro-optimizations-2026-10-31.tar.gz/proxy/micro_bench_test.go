package proxy

import (
	"bytes"
	"context"
	"encoding/binary"
	"fmt"
	"hash/fnv"
	"net"
	"testing"
	"time"

	"github.com/nextdns/nextdns/discovery"
	"github.com/nextdns/nextdns/resolver/query"
	"golang.org/x/net/dns/dnsmessage"
)

var microCount int
var microError error

func microQuestion(t testing.TB, name string, typ dnsmessage.Type) query.Query {
	t.Helper()
	payload, err := (&dnsmessage.Message{Header: dnsmessage.Header{ID: 123, RecursionDesired: true}, Questions: []dnsmessage.Question{{Name: dnsmessage.MustNewName(name), Type: typ, Class: dnsmessage.ClassINET}}}).Pack()
	if err != nil {
		t.Fatal(err)
	}
	q, err := query.New(payload, net.IPv4(127, 0, 0, 1), nil)
	if err != nil {
		t.Fatal(err)
	}
	return q
}

func BenchmarkMicroReadTCP(b *testing.B) {
	for _, size := range []int{32, 512, 4096} {
		b.Run(fmt.Sprint(size), func(b *testing.B) {
			frame := make([]byte, size+2)
			binary.BigEndian.PutUint16(frame, uint16(size))
			r := bytes.NewReader(frame)
			buf := make([]byte, maxTCPSize)
			b.ReportAllocs()
			for b.Loop() {
				r.Reset(frame)
				n, err := readTCP(r, buf)
				if err != nil || n != size {
					b.Fatalf("readTCP=%d/%v", n, err)
				}
				microCount = n
			}
		})
	}
}

func BenchmarkMicroHostsMiss(b *testing.B) {
	q := microQuestion(b, "missing.invalid.", dnsmessage.TypeA)
	buf := make([]byte, 512)
	r := discovery.Dummy{}
	b.ReportAllocs()
	for b.Loop() {
		_, _, microError = hostsResolve(r, q, buf)
	}
}

func BenchmarkMicroHostsHit(b *testing.B) {
	q := microQuestion(b, "localhost.", dnsmessage.TypeA)
	r := &discovery.Hosts{}
	if len(r.LookupHost(q.Name)) == 0 {
		b.Fatal("no local localhost hosts entry")
	}
	p := Proxy{LocalResolver: discovery.Resolver{r}}
	buf := make([]byte, 512)
	ctx := context.Background()
	b.ReportAllocs()
	for b.Loop() {
		n, _, err := p.Resolve(ctx, q, buf)
		if err != nil || n == 0 {
			b.Fatalf("Resolve=%d/%v", n, err)
		}
		microCount = n
	}
}

func BenchmarkMicroPTRPolicy(b *testing.B) {
	q := microQuestion(b, "1.0.0.127.in-addr.arpa.", dnsmessage.TypePTR)
	r := &discovery.Hosts{}
	if len(r.LookupAddr("127.0.0.1")) == 0 {
		b.Fatal("no local reverse hosts entry")
	}
	for _, policy := range []bool{false, true} {
		b.Run(fmt.Sprint(policy), func(b *testing.B) {
			p := Proxy{BogusPriv: policy, Upstream: Proxy{LocalResolver: discovery.Resolver{r}}}
			buf := make([]byte, 512)
			ctx := context.Background()
			b.ReportAllocs()
			for b.Loop() {
				n, _, err := p.Resolve(ctx, q, buf)
				if err != nil || n == 0 {
					b.Fatalf("Resolve=%d/%v", n, err)
				}
				microCount = n
			}
		})
	}
}

func microUDPProxy(t testing.TB, network string) (*net.UDPConn, query.Query) {
	t.Helper()
	addr := "127.0.0.1:0"
	if network == "udp6" {
		addr = "[::1]:0"
	}
	server, err := net.ListenPacket(network, addr)
	if err != nil {
		t.Fatal(err)
	}
	r := &discovery.Hosts{}
	if len(r.LookupHost("localhost.")) == 0 {
		server.Close()
		t.Fatal("no local hosts entry")
	}
	p := Proxy{LocalResolver: discovery.Resolver{r}}
	done := make(chan error, 1)
	go func() { done <- p.serveUDP(server, make(chan struct{}, 256)) }()
	client, err := net.DialUDP(network, nil, server.LocalAddr().(*net.UDPAddr))
	if err != nil {
		server.Close()
		<-done
		t.Fatal(err)
	}
	t.Cleanup(func() { client.Close(); server.Close(); <-done })
	if err := client.SetDeadline(time.Now().Add(3 * time.Minute)); err != nil {
		t.Fatal(err)
	}
	return client, microQuestion(t, "localhost.", dnsmessage.TypeA)
}

func BenchmarkMicroUDP(b *testing.B) {
	for _, network := range []string{"udp4", "udp6"} {
		b.Run(network, func(b *testing.B) {
			client, q := microUDPProxy(b, network)
			buf := make([]byte, 512)
			b.ReportAllocs()
			for b.Loop() {
				if _, err := client.Write(q.Payload); err != nil {
					b.Fatal(err)
				}
				n, err := client.Read(buf)
				if err != nil || n < 12 {
					b.Fatalf("UDP=%d/%v", n, err)
				}
				microCount = n
			}
		})
	}
}

func TestMicroTCPFingerprint(t *testing.T) {
	h := fnv.New64a()
	for _, frame := range [][]byte{nil, {0}, {0, 0}, {0, 1}, {0, 1, 5}, {0, 3, 1, 2}, {0, 3, 1, 2, 3}} {
		r := bytes.NewReader(frame)
		buf := make([]byte, 512)
		n, err := readTCP(r, buf)
		var result []byte
		if n > 0 {
			result = buf[:n]
		}
		fmt.Fprintf(h, "%d/%v/%x\n", n, err, result)
	}
	t.Logf("tcp-fingerprint=%x", h.Sum64())
}

func TestMicroUDPSmoke(t *testing.T) {
	for _, network := range []string{"udp4", "udp6"} {
		t.Run(network, func(t *testing.T) {
			client, q := microUDPProxy(t, network)
			if _, err := client.Write(q.Payload); err != nil {
				t.Fatal(err)
			}
			buf := make([]byte, 512)
			n, err := client.Read(buf)
			if err != nil {
				t.Fatal(err)
			}
			var msg dnsmessage.Message
			if err := msg.Unpack(buf[:n]); err != nil {
				t.Fatal(err)
			}
			if !msg.Response || msg.ID != q.ID || len(msg.Answers) == 0 {
				t.Fatalf("bad UDP answer: %+v", msg)
			}
		})
	}
}
